package com.leah.llab1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Llab1Application {

	public static void main(String[] args) {
		SpringApplication.run(Llab1Application.class, args);
	}

}
