package com.leah.llab1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;



@RestController

@RequestMapping("/lab1/users")
public class UserController {

    @GetMapping
    public User getUser() {
        return User.builder().username("Flor").password("Leyah").build();
    }
    
}
 